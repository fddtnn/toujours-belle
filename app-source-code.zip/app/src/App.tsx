import { useEffect, useState, useCallback, useRef } from 'react';
import { Routes, Route } from 'react-router';
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

import { LanguageProvider } from './context/LanguageContext';
import Navigation from './components/Navigation';
import CartDrawer from './components/CartDrawer';
import Hero from './sections/Hero';
import HairTypes from './sections/HairTypes';
import ColorSelection from './sections/ColorSelection';
import About from './sections/About';
import ProductSection from './sections/ProductSection';
import Testimonials from './sections/Testimonials';
import Footer from './sections/Footer';
import FAQ from './pages/FAQ';
import Conditions from './pages/Conditions';

gsap.registerPlugin(ScrollTrigger);

interface CartItem {
  type: string;
  color: string;
  length: string;
  quantity: number;
  price: number;
}

function HomePage() {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [productType, setProductType] = useState<string | undefined>(undefined);
  const lenisRef = useRef<Lenis | null>(null);

  // Initialize Lenis smooth scroll
  useEffect(() => {
    const lenis = new Lenis({
      lerp: 0.08,
      smoothWheel: true,
    });
    lenisRef.current = lenis;

    lenis.on('scroll', ScrollTrigger.update);

    gsap.ticker.add((time) => {
      lenis.raf(time * 1000);
    });

    gsap.ticker.lagSmoothing(0);

    return () => {
      lenis.destroy();
      lenisRef.current = null;
    };
  }, []);

  const handleAddToCart = useCallback((item: CartItem) => {
    setCartItems((prev) => [...prev, item]);
  }, []);

  const handleRemoveFromCart = useCallback((index: number) => {
    setCartItems((prev) => prev.filter((_, i) => i !== index));
  }, []);

  const handleSelectType = useCallback((type: string) => {
    setProductType(type);
    setTimeout(() => {
      document.querySelector('#product')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  }, []);

  const cartCount = cartItems.length;

  return (
    <>
      <Navigation cartCount={cartCount} onCartClick={() => setCartOpen(true)} />

      <main>
        <Hero />
        <HairTypes onSelectType={handleSelectType} />
        <ColorSelection />
        <About />
        <ProductSection onAddToCart={handleAddToCart} initialType={productType} />
        <Testimonials />
        <Footer />
      </main>

      <CartDrawer
        isOpen={cartOpen}
        onClose={() => setCartOpen(false)}
        items={cartItems}
        onRemove={handleRemoveFromCart}
      />
    </>
  );
}

export default function App() {
  return (
    <LanguageProvider>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/faq" element={<FAQ />} />
        <Route path="/conditions" element={<Conditions />} />
      </Routes>
    </LanguageProvider>
  );
}
