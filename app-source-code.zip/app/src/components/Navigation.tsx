import { useEffect, useState, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { useLanguage } from '../context/LanguageContext';
import { ShoppingCart, Menu, X, Sparkles } from 'lucide-react';
import gsap from 'gsap';

interface NavigationProps {
  cartCount: number;
  onCartClick: () => void;
}

export default function Navigation({ cartCount, onCartClick }: NavigationProps) {
  const { lang, toggleLang, isRTL } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const navRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (navRef.current) {
      gsap.fromTo(
        navRef.current,
        { y: -64, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.8, ease: 'power3.out', delay: 0.2 }
      );
    }
  }, []);

  const navLinks = [
    { fr: 'Accueil', ar: 'الرئيسية', href: '#hero' },
    { fr: 'Nos Cheveux', ar: 'شعرنا', href: '#hair-types' },
    { fr: 'Couleurs', ar: 'الألوان', href: '#colors' },
    { fr: '\u00c0 Propos', ar: 'من نحن', href: '#about' },
    { fr: 'FAQ', ar: 'الأسئلة', href: '/faq' },
    { fr: 'Contact', ar: 'تواصل', href: '#footer' },
  ];

  const scrollToSection = (href: string) => {
    setMobileOpen(false);
    if (href.startsWith('/')) {
      navigate(href);
      return;
    }
    if (location.pathname !== '/') {
      navigate('/' + href);
      return;
    }
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      <nav
        ref={navRef}
        className="fixed top-0 left-0 right-0 h-16 flex items-center justify-between px-6 lg:px-10"
        style={{
          zIndex: 100,
          backgroundColor: scrolled ? 'rgba(250, 246, 244, 0.85)' : 'transparent',
          backdropFilter: scrolled ? 'blur(12px)' : 'none',
          borderBottom: scrolled ? '1px solid #f0e0e0' : '1px solid transparent',
          transition: 'all 0.4s ease',
        }}
      >
        {/* Brand */}
        <a
          href="#hero"
          onClick={(e) => {
            e.preventDefault();
            scrollToSection('#hero');
          }}
          className="text-lg tracking-wide flex items-center gap-2"
          style={{ fontFamily: "'Playfair Display', serif", color: '#1a1a1a' }}
        >
          <Sparkles size={18} color="#d4a5a5" />
          Toujours Belle
        </a>

        {/* Center Links - Desktop */}
        <div
          className="hidden lg:flex items-center gap-8"
          style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}
        >
          {navLinks.map((link) => (
            <a
              key={link.fr}
              href={link.href}
              onClick={(e) => {
                e.preventDefault();
                scrollToSection(link.href);
              }}
              className="text-xs uppercase tracking-widest hover:text-[#d4a5a5] transition-colors duration-300"
              style={{
                fontFamily: "'Inter', sans-serif",
                fontWeight: 500,
                color: '#1a1a1a',
                letterSpacing: '0.1em',
              }}
            >
              {lang === 'fr' ? link.fr : link.ar}
            </a>
          ))}
        </div>

        {/* Right Actions */}
        <div
          className="flex items-center gap-4"
          style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}
        >
          <button
            onClick={toggleLang}
            className="text-xs uppercase tracking-widest hover:text-[#d4a5a5] transition-colors duration-300"
            style={{ fontWeight: 500, color: '#1a1a1a' }}
          >
            {lang === 'fr' ? 'AR' : 'FR'}
          </button>

          <button
            onClick={onCartClick}
            className="relative p-2 hover:text-[#d4a5a5] transition-colors duration-300"
            style={{ color: '#1a1a1a' }}
            aria-label="Cart"
          >
            <ShoppingCart size={20} />
            {cartCount > 0 && (
              <span
                className="absolute -top-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center text-white text-xs"
                style={{ backgroundColor: '#d4a5a5', fontSize: '10px', fontWeight: 600 }}
              >
                {cartCount}
              </span>
            )}
          </button>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Menu"
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu Drawer */}
      <div
        className={`fixed inset-0 z-[99] lg:hidden transition-opacity duration-300 ${
          mobileOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div
          className="absolute inset-0 bg-black/20"
          onClick={() => setMobileOpen(false)}
        />
        <div
          className={`absolute top-0 ${isRTL ? 'left-0' : 'right-0'} w-72 h-full bg-[#faf6f4] shadow-xl transition-transform duration-300 ${
            mobileOpen ? 'translate-x-0' : isRTL ? '-translate-x-full' : 'translate-x-full'
          }`}
          style={{ paddingTop: '80px' }}
        >
          <div className="flex flex-col gap-6 px-8">
            {navLinks.map((link) => (
              <a
                key={link.fr}
                href={link.href}
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection(link.href);
                }}
                className="text-sm uppercase tracking-widest hover:text-[#d4a5a5] transition-colors duration-300"
                style={{
                  fontWeight: 500,
                  color: '#1a1a1a',
                  letterSpacing: '0.1em',
                }}
              >
                {lang === 'fr' ? link.fr : link.ar}
              </a>
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
