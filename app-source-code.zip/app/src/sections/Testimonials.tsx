import { useEffect, useRef, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ChevronLeft, ChevronRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

interface Testimonial {
  quoteFr: string;
  quoteAr: string;
  authorFr: string;
  authorAr: string;
  image: string;
}

const testimonials: Testimonial[] = [
  {
    quoteFr: "Les cheveux sont d'une qualit\u00e9 exceptionnelle ! Ils sont doux, soyeux et tiennent parfaitement les boucles. Je re\u00e7ois des compliments tous les jours.",
    quoteAr: 'الشعر بجودة استثنائية! إنه ناعم وحريري ويحتفظ بالخصلات بشكل مثالي. أتلقى المجاملات كل يوم.',
    authorFr: '\u2014 Amina, Paris',
    authorAr: '\u2014 أمينة، باريس',
    image: '/images/testimonial-1.jpg',
  },
  {
    quoteFr: "J'ai enfin trouv\u00e9 des cheveux naturels qui correspondent parfaitement \u00e0 ma texture. La qualit\u00e9 est incomparable et le service client est adorable.",
    quoteAr: 'وجدت أخيرًا شعرًا طبيعيًا يتوافق تمامًا مع ملمس شعري. الجودة لا مثيل لها وخدمة العملاء رائعة.',
    authorFr: '\u2014 Sarah, Lyon',
    authorAr: '\u2014 سارة، ليون',
    image: '/images/testimonial-2.jpg',
  },
  {
    quoteFr: "Toujours Belle a chang\u00e9 ma vie ! Mes extensions sont ind\u00e9tectables et se fondent parfaitement avec mes cheveux. Je recommande \u00e0 100%.",
    quoteAr: 'غيرت Toujours Belle حياتي! إضافاتي غير قابلة للاكتشاف وتندمج تمامًا مع شعري. أنصح بها 100٪.',
    authorFr: '\u2014 Fatima, Marseille',
    authorAr: '\u2014 فاطمة، مرسيليا',
    image: '/images/testimonial-3.jpg',
  },
];

export default function Testimonials() {
  const { lang, isRTL } = useLanguage();
  const sectionRef = useRef<HTMLElement>(null);
  const quoteRef = useRef<HTMLDivElement>(null);
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (quoteRef.current) {
        gsap.fromTo(
          quoteRef.current,
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 1,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 75%',
              toggleActions: 'play none none none',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const prev = () => setCurrent((c) => (c === 0 ? testimonials.length - 1 : c - 1));
  const next = () => setCurrent((c) => (c === testimonials.length - 1 ? 0 : c + 1));

  const t = testimonials[current];

  return (
    <section
      ref={sectionRef}
      className="relative w-full"
      style={{
        zIndex: 1,
        backgroundColor: '#faf6f4',
        padding: '120px 0',
      }}
    >
      <div className="max-w-[1000px] mx-auto px-6 lg:px-10 text-center">
        <p
          style={{
            fontFamily: "'Inter', sans-serif",
            fontWeight: 500,
            fontSize: '11px',
            letterSpacing: '0.15em',
            textTransform: 'uppercase',
            color: '#8a8a8a',
            marginBottom: '32px',
          }}
        >
          {lang === 'fr' ? 'T\u00c9MOIGNAGES' : 'آراء العملاء'}
        </p>

        <div ref={quoteRef}>
          {/* Avatar */}
          <div
            className="mx-auto mb-6 rounded-full overflow-hidden"
            style={{ width: '80px', height: '80px' }}
          >
            <img
              src={t.image}
              alt=""
              className="w-full h-full object-cover"
            />
          </div>

          <blockquote
            style={{
              fontFamily: "'Playfair Display', serif",
              fontWeight: 400,
              fontStyle: 'italic',
              fontSize: 'clamp(1.3rem, 2.5vw, 1.8rem)',
              lineHeight: 1.5,
              color: '#1a1a1a',
              marginBottom: '32px',
              transition: 'opacity 0.3s ease',
            }}
            key={current}
          >
            "{lang === 'fr' ? t.quoteFr : t.quoteAr}"
          </blockquote>

          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: 500,
              fontSize: '14px',
              color: '#8a8a8a',
              marginBottom: '32px',
            }}
          >
            {lang === 'fr' ? t.authorFr : t.authorAr}
          </p>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-center gap-4">
          <button
            onClick={prev}
            className="w-10 h-10 rounded-full border border-[#1a1a1a] flex items-center justify-center hover:bg-[#1a1a1a] hover:text-[#faf6f4] transition-all duration-300"
            style={{ color: '#1a1a1a' }}
            aria-label="Previous"
          >
            {isRTL ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
          </button>

          <div className="flex gap-2">
            {testimonials.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setCurrent(idx)}
                className="rounded-full transition-all duration-300"
                style={{
                  width: '8px',
                  height: '8px',
                  backgroundColor: current === idx ? '#1a1a1a' : '#d4a5a5',
                }}
                aria-label={`Go to testimonial ${idx + 1}`}
              />
            ))}
          </div>

          <button
            onClick={next}
            className="w-10 h-10 rounded-full border border-[#1a1a1a] flex items-center justify-center hover:bg-[#1a1a1a] hover:text-[#faf6f4] transition-all duration-300"
            style={{ color: '#1a1a1a' }}
            aria-label="Next"
          >
            {isRTL ? <ChevronLeft size={18} /> : <ChevronRight size={18} />}
          </button>
        </div>
      </div>
    </section>
  );
}
