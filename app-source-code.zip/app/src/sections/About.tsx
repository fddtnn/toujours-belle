import { useEffect, useRef } from 'react';
import { useLanguage } from '../context/LanguageContext';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function About() {
  const { t, lang, isRTL } = useLanguage();
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (imageRef.current) {
        gsap.fromTo(
          imageRef.current,
          { opacity: 0, x: isRTL ? 80 : -80 },
          {
            opacity: 1,
            x: 0,
            duration: 1.2,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
              toggleActions: 'play none none none',
            },
          }
        );
      }

      if (textRef.current) {
        const elements = textRef.current.querySelectorAll('.animate-in');
        gsap.fromTo(
          elements,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            ease: 'power3.out',
            stagger: 0.12,
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 70%',
              toggleActions: 'play none none none',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, [isRTL]);

  const stats = [
    { value: '10+', valueAr: '+10', labelFr: "Ann\u00e9es d'Exp\u00e9rience", labelAr: 'سنوات الخبرة' },
    { value: '50K+', valueAr: '+50 ألف', labelFr: 'Clientes Satisfaites', labelAr: 'زبونة راضية' },
    { value: '16+', valueAr: '+16', labelFr: 'Teintes Disponibles', labelAr: 'لونًا متاحًا' },
  ];

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative w-full overflow-hidden"
      style={{
        zIndex: 1,
        backgroundColor: '#faf6f4',
        padding: '0',
      }}
    >
      <div
        className="flex flex-col lg:flex-row"
        style={{ minHeight: '600px', flexDirection: isRTL ? 'row-reverse' : undefined }}
      >
        {/* Image */}
        <div
          ref={imageRef}
          className="w-full lg:w-1/2"
          style={{ minHeight: '400px', maxHeight: '700px' }}
        >
          <img
            src="/images/about.jpg"
            alt="About Toujours Belle"
            className="w-full h-full object-cover"
            loading="lazy"
          />
        </div>

        {/* Text Content */}
        <div
          ref={textRef}
          className="w-full lg:w-1/2 flex flex-col justify-center"
          style={{ padding: '80px 40px', paddingLeft: isRTL ? '40px' : '80px', paddingRight: isRTL ? '80px' : '40px' }}
        >
          <p
            className="animate-in"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: 500,
              fontSize: '11px',
              letterSpacing: '0.15em',
              textTransform: 'uppercase',
              color: '#8a8a8a',
              marginBottom: '16px',
            }}
          >
            {t({ fr: 'NOTRE HISTOIRE', ar: 'قصتنا' })}
          </p>

          <h2
            className="animate-in"
            style={{
              fontFamily: "'Playfair Display', serif",
              fontWeight: 400,
              fontSize: 'clamp(2rem, 4vw, 3.5rem)',
              lineHeight: 1.15,
              color: '#1a1a1a',
              marginBottom: '24px',
            }}
          >
            {t({ fr: 'La Passion du Cheveu Naturel', ar: 'شغف الشعر الطبيعي' })}
          </h2>

          <p
            className="animate-in"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: 400,
              fontSize: '16px',
              lineHeight: 1.7,
              color: '#8a8a8a',
              marginBottom: '16px',
            }}
          >
            {t({
              fr: "Toujours Belle est n\u00e9 d'une passion profonde pour la beaut\u00e9 authentique. Nous croyons que chaque femme m\u00e9rite de se sentir belle et confiante, et nos cheveux naturels sont l\u00e0 pour sublimer votre \u00e9l\u00e9gance naturelle.",
              ar: 'ولدت Toujours Belle من شغف عميق بالجمال الأصيل. نؤمن أن كل امرأة تستحق أن تشعر بالجمال والثقة، وشعرنا الطبيعي هنا لتجميل أناقتكِ الطبيعية.',
            })}
          </p>

          <p
            className="animate-in"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: 400,
              fontSize: '16px',
              lineHeight: 1.7,
              color: '#8a8a8a',
              marginBottom: '32px',
            }}
          >
            {t({
              fr: "Nos cheveux sont 100% naturels, soigneusement s\u00e9lectionn\u00e9s et trait\u00e9s avec les plus hauts standards de qualit\u00e9. Ils sont doux, soyeux et durables \u2014 con\u00e7us pour vous accompagner dans chaque moment de votre vie.",
              ar: 'شعرنا 100٪ طبيعي، مختار بعناية ومعالج بأعلى معايير الجودة. إنه ناعم وحريري وطويل الأمد — مصمم ليرافقكِ في كل لحظة من حياتكِ.',
            })}
          </p>

          {/* Stats */}
          <div
            className="animate-in flex gap-8 lg:gap-12 mb-8"
            style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}
          >
            {stats.map((stat) => (
              <div key={stat.value} className="text-center">
                <p
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontWeight: 400,
                    fontSize: '36px',
                    color: '#d4a5a5',
                    lineHeight: 1.2,
                  }}
                >
                  {lang === 'fr' ? stat.value : stat.valueAr}
                </p>
                <p
                  style={{
                    fontFamily: "'Inter', sans-serif",
                    fontWeight: 400,
                    fontSize: '13px',
                    color: '#8a8a8a',
                    marginTop: '4px',
                  }}
                >
                  {lang === 'fr' ? stat.labelFr : stat.labelAr}
                </p>
              </div>
            ))}
          </div>

          <a
            href="#product"
            onClick={(e) => {
              e.preventDefault();
              document.querySelector('#product')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="animate-in inline-block"
            style={{
              padding: '14px 36px',
              borderRadius: '100px',
              border: '1px solid #1a1a1a',
              backgroundColor: 'transparent',
              color: '#1a1a1a',
              fontFamily: "'Inter', sans-serif",
              fontWeight: 500,
              fontSize: '13px',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              textDecoration: 'none',
              transition: 'all 0.3s ease',
              width: 'fit-content',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = '#1a1a1a';
              e.currentTarget.style.color = '#faf6f4';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
              e.currentTarget.style.color = '#1a1a1a';
            }}
          >
            {t({ fr: 'En Savoir Plus', ar: 'تعرفي أكثر' })}
          </a>
        </div>
      </div>
    </section>
  );
}
