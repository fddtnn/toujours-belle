import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router';
import { useLanguage } from '../context/LanguageContext';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Instagram, Mail, Phone, Sparkles } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function Footer() {
  const { lang, isRTL } = useLanguage();
  const navigate = useNavigate();
  const sectionRef = useRef<HTMLElement>(null);
  const newsletterRef = useRef<HTMLDivElement>(null);
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (newsletterRef.current) {
        gsap.fromTo(
          newsletterRef.current,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: newsletterRef.current,
              start: 'top 80%',
              toggleActions: 'play none none none',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubscribed(true);
      setEmail('');
    }
  };

  return (
    <section
      ref={sectionRef}
      id="footer"
      className="relative w-full"
      style={{ zIndex: 1 }}
    >
      {/* Newsletter */}
      <div
        ref={newsletterRef}
        style={{
          backgroundColor: '#1a1a1a',
          padding: '100px 40px',
          textAlign: 'center',
        }}
      >
        <h2
          style={{
            fontFamily: "'Playfair Display', serif",
            fontWeight: 400,
            fontSize: 'clamp(1.8rem, 3vw, 2.5rem)',
            color: '#faf6f4',
            marginBottom: '16px',
          }}
        >
          {lang === 'fr' ? 'Rejoignez Notre Communaut\u00e9' : 'انضمي إلى مجتمعنا'}
        </h2>
        <p
          style={{
            fontFamily: "'Inter', sans-serif",
            fontWeight: 400,
            fontSize: '16px',
            color: '#8a8a8a',
            maxWidth: '480px',
            margin: '0 auto 32px',
            lineHeight: 1.6,
          }}
        >
          {lang === 'fr'
            ? "Inscrivez-vous pour recevoir nos offres exclusives et d\u00e9couvrir nos nouvelles collections en avant-premi\u00e8re."
            : 'سجلي للحصول على عروضنا الحصرية واكتشاف مجموعاتنا الجديدة قبل الجميع.'}
        </p>

        {subscribed ? (
          <p
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: 500,
              fontSize: '14px',
              color: '#d4a5a5',
            }}
          >
            {lang === 'fr' ? 'Merci pour votre inscription ! \u2713' : 'شكرًا لاشتراككِ! \u2713'}
          </p>
        ) : (
          <form
            onSubmit={handleSubscribe}
            className="flex flex-col sm:flex-row items-center justify-center gap-0"
            style={{ flexDirection: isRTL ? 'row-reverse' : undefined }}
          >
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder={lang === 'fr' ? 'Votre adresse email' : 'بريدكِ الإلكتروني'}
              required
              style={{
                width: '100%',
                maxWidth: '320px',
                padding: '14px 24px',
                borderRadius: '100px',
                backgroundColor: 'rgba(250,246,244,0.1)',
                border: '1px solid rgba(250,246,244,0.2)',
                color: '#faf6f4',
                fontFamily: "'Inter', sans-serif",
                fontSize: '14px',
                outline: 'none',
              }}
            />
            <button
              type="submit"
              style={{
                padding: '14px 32px',
                borderRadius: '100px',
                backgroundColor: '#d4a5a5',
                color: '#1a1a1a',
                fontFamily: "'Inter', sans-serif",
                fontWeight: 500,
                fontSize: '13px',
                letterSpacing: '0.08em',
                textTransform: 'uppercase',
                border: 'none',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                marginLeft: isRTL ? '0' : '-48px',
                marginRight: isRTL ? '-48px' : '0',
                marginTop: isRTL ? '0' : '12px',
              }}
              className="sm:mt-0 hover:brightness-110"
            >
              {lang === 'fr' ? "S'inscrire" : 'اشتركي'}
            </button>
          </form>
        )}
      </div>

      {/* Footer */}
      <footer
        style={{
          backgroundColor: '#faf6f4',
          padding: '60px 40px 30px',
        }}
      >
        <div className="max-w-[1200px] mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
            {/* Brand */}
            <div>
              <p
                className="flex items-center gap-2"
                style={{
                  fontFamily: "'Playfair Display', serif",
                  fontWeight: 400,
                  fontSize: '18px',
                  color: '#1a1a1a',
                  marginBottom: '12px',
                }}
              >
                <Sparkles size={16} color="#d4a5a5" />
                Toujours Belle
              </p>
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontWeight: 400,
                  fontSize: '14px',
                  color: '#8a8a8a',
                  lineHeight: 1.6,
                }}
              >
                {lang === 'fr'
                  ? "La beaut\u00e9 naturelle \u00e0 port\u00e9e de main."
                  : 'الجمال الطبيعي في متناول يدكِ.'}
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontWeight: 500,
                  fontSize: '12px',
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                  color: '#1a1a1a',
                  marginBottom: '16px',
                }}
              >
                {lang === 'fr' ? 'Liens Rapides' : 'روابط سريعة'}
              </p>
              <ul className="space-y-2">
                {[
                  { fr: 'Accueil', ar: 'الرئيسية', href: '#hero' },
                  { fr: 'Collection', ar: 'المجموعة', href: '#hair-types' },
                  { fr: '\u00c0 Propos', ar: 'من نحن', href: '#about' },
                  { fr: 'FAQ', ar: 'الأسئلة', href: '/faq' },
                  { fr: 'Contact', ar: 'تواصل', href: '#footer' },
                ].map((link) => (
                  <li key={link.fr}>
                    <a
                      href={link.href}
                      onClick={(e) => {
                        e.preventDefault();
                        if (link.href.startsWith('/')) {
                          navigate(link.href);
                        } else {
                          document.querySelector(link.href)?.scrollIntoView({ behavior: 'smooth' });
                        }
                      }}
                      className="hover:text-[#d4a5a5] transition-colors duration-300"
                      style={{
                        fontFamily: "'Inter', sans-serif",
                        fontSize: '14px',
                        color: '#8a8a8a',
                        textDecoration: 'none',
                        cursor: 'pointer',
                      }}
                    >
                      {lang === 'fr' ? link.fr : link.ar}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Info */}
            <div>
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontWeight: 500,
                  fontSize: '12px',
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                  color: '#1a1a1a',
                  marginBottom: '16px',
                }}
              >
                {lang === 'fr' ? 'Informations' : 'معلومات'}
              </p>
              <ul className="space-y-2">
                {[
                  { fr: 'Livraison', ar: 'التوصيل', href: '#' },
                  { fr: 'Retours', ar: 'الإرجاع', href: '/conditions' },
                  { fr: 'FAQ', ar: 'الأسئلة الشائعة', href: '/faq' },
                  { fr: 'Conditions G\u00e9n\u00e9rales', ar: 'الشروط العامة', href: '/conditions' },
                ].map((link) => (
                  <li key={link.fr}>
                    <a
                      href={link.href}
                      onClick={(e) => {
                        e.preventDefault();
                        if (link.href.startsWith('/')) {
                          navigate(link.href);
                        }
                      }}
                      className="hover:text-[#d4a5a5] transition-colors duration-300"
                      style={{
                        fontFamily: "'Inter', sans-serif",
                        fontSize: '14px',
                        color: '#8a8a8a',
                        textDecoration: 'none',
                        cursor: link.href.startsWith('/') ? 'pointer' : 'default',
                      }}
                    >
                      {lang === 'fr' ? link.fr : link.ar}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Contact */}
            <div>
              <p
                style={{
                  fontFamily: "'Inter', sans-serif",
                  fontWeight: 500,
                  fontSize: '12px',
                  letterSpacing: '0.1em',
                  textTransform: 'uppercase',
                  color: '#1a1a1a',
                  marginBottom: '16px',
                }}
              >
                {lang === 'fr' ? 'Contact' : 'تواصل'}
              </p>
              <div className="space-y-3">
                <div
                  className="flex items-center gap-2"
                  style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}
                >
                  <Mail size={16} color="#8a8a8a" />
                  <span
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '14px',
                      color: '#8a8a8a',
                    }}
                  >
                    contact@toujoursbelle.com
                  </span>
                </div>
                <div
                  className="flex items-center gap-2"
                  style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}
                >
                  <Phone size={16} color="#8a8a8a" />
                  <span
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '14px',
                      color: '#8a8a8a',
                    }}
                  >
                    +33 1 23 45 67 89
                  </span>
                </div>
                <div
                  className="flex items-center gap-2"
                  style={{ flexDirection: isRTL ? 'row-reverse' : 'row' }}
                >
                  <Instagram size={16} color="#8a8a8a" />
                  <span
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '14px',
                      color: '#8a8a8a',
                    }}
                  >
                    @toujoursbelle.officiel
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Bar */}
          <div
            className="mt-10 pt-6 text-center"
            style={{ borderTop: '1px solid #f0e0e0' }}
          >
            <p
              style={{
                fontFamily: "'Inter', sans-serif",
                fontWeight: 400,
                fontSize: '12px',
                color: '#8a8a8a',
              }}
            >
              © 2024 Toujours Belle. {lang === 'fr' ? 'Tous droits r\u00e9serv\u00e9s.' : 'جميع الحقوق محفوظة.'}
            </p>
          </div>
        </div>
      </footer>
    </section>
  );
}
