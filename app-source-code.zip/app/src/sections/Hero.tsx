import { useEffect, useRef } from 'react';
import { useLanguage } from '../context/LanguageContext';
import gsap from 'gsap';

export default function Hero() {
  const { t, isRTL } = useLanguage();
  const overlineRef = useRef<HTMLParagraphElement>(null);
  const line1Ref = useRef<HTMLSpanElement>(null);
  const line2Ref = useRef<HTMLSpanElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLAnchorElement>(null);

  useEffect(() => {
    const tl = gsap.timeline({ delay: 0.3 });

    tl.to(overlineRef.current, {
      opacity: 1,
      y: 0,
      duration: 0.6,
      ease: 'power3.out',
    })
      .to(
        line1Ref.current,
        { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' },
        '-=0.3'
      )
      .to(
        line2Ref.current,
        { opacity: 1, y: 0, duration: 0.8, ease: 'power3.out' },
        '-=0.65'
      )
      .to(
        subtitleRef.current,
        { opacity: 1, y: 0, duration: 0.7, ease: 'power3.out' },
        '-=0.5'
      )
      .to(
        ctaRef.current,
        { opacity: 1, y: 0, duration: 0.6, ease: 'power3.out' },
        '-=0.4'
      );

    return () => {
      tl.kill();
    };
  }, []);

  return (
    <section
      id="hero"
      className="relative w-full overflow-hidden"
      style={{ height: '100vh', zIndex: 1, backgroundColor: '#faf6f4' }}
    >
      {/* Video Background */}
      <div
        className="absolute inset-0"
        style={{ zIndex: 0 }}
      >
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover"
          style={{
            objectPosition: 'center 30%',
            transform: 'scale(1.05)',
          }}
        >
          <source src="/videos/hero-video.mp4" type="video/mp4" />
        </video>
        {/* Gradient overlay - softer, lets more video show */}
        <div
          className="absolute inset-0"
          style={{
            background: isRTL
              ? 'linear-gradient(to left, rgba(250,246,244,0.92) 0%, rgba(250,246,244,0.5) 40%, rgba(250,246,244,0.15) 70%, transparent 100%)'
              : 'linear-gradient(to right, rgba(250,246,244,0.92) 0%, rgba(250,246,244,0.5) 40%, rgba(250,246,244,0.15) 70%, transparent 100%)',
          }}
        />
        {/* Bottom fade for smooth transition to next section */}
        <div
          className="absolute bottom-0 left-0 right-0"
          style={{
            height: '120px',
            background: 'linear-gradient(to top, rgba(250,246,244,1) 0%, transparent 100%)',
          }}
        />
      </div>

      {/* Text Content */}
      <div
        className="absolute inset-0 flex items-center"
        style={{ zIndex: 2 }}
      >
        <div
          className="flex flex-col justify-center"
          style={{
            padding: isRTL ? '0 8vw 0 0' : '0 0 0 8vw',
            maxWidth: '600px',
            textAlign: isRTL ? 'right' : 'left',
            marginLeft: isRTL ? 'auto' : '0',
            marginRight: isRTL ? '0' : 'auto',
          }}
        >
          <p
            ref={overlineRef}
            className="opacity-0 translate-y-5"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: 500,
              fontSize: '11px',
              letterSpacing: '0.15em',
              textTransform: 'uppercase',
              color: '#8a8a8a',
              marginBottom: '16px',
            }}
          >
            {t({ fr: '100% CHEVEUX NATURELS', ar: '100٪ شعر طبيعي' })}
          </p>

          <h1
            style={{
              fontFamily: "'Playfair Display', serif",
              fontWeight: 400,
              fontSize: 'clamp(2.5rem, 5vw, 4.5rem)',
              lineHeight: 1.1,
              color: '#1a1a1a',
            }}
          >
            <span ref={line1Ref} className="block opacity-0 translate-y-10">
              {t({ fr: 'La Beaut\u00e9', ar: 'جمال' })}
            </span>
            <span ref={line2Ref} className="block opacity-0 translate-y-10">
              {t({ fr: 'de Vos Cheveux', ar: 'شعركِ' })}
            </span>
          </h1>

          <p
            ref={subtitleRef}
            className="opacity-0 translate-y-8"
            style={{
              fontFamily: "'Inter', sans-serif",
              fontWeight: 400,
              fontSize: '18px',
              lineHeight: 1.6,
              color: '#8a8a8a',
              marginTop: '24px',
              maxWidth: '480px',
            }}
          >
            {t({
              fr: 'D\u00e9couvrez notre collection de cheveux naturels, soigneusement s\u00e9lectionn\u00e9s pour sublimer votre \u00e9l\u00e9gance.',
              ar: 'اكتشفي مجموعتنا من الشعر الطبيعي، المختارة بعناية لتجميل أناقتكِ.',
            })}
          </p>

          <a
            ref={ctaRef}
            href="#hair-types"
            onClick={(e) => {
              e.preventDefault();
              document.querySelector('#hair-types')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="opacity-0 translate-y-5 inline-block"
            style={{
              marginTop: '32px',
              backgroundColor: '#1a1a1a',
              color: '#faf6f4',
              borderRadius: '100px',
              padding: '14px 36px',
              fontFamily: "'Inter', sans-serif",
              fontWeight: 500,
              fontSize: '13px',
              letterSpacing: '0.08em',
              textTransform: 'uppercase',
              textDecoration: 'none',
              transition: 'all 0.3s ease',
              width: 'fit-content',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = '#d4a5a5';
              e.currentTarget.style.color = '#1a1a1a';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = '#1a1a1a';
              e.currentTarget.style.color = '#faf6f4';
            }}
          >
            {t({ fr: 'D\u00e9couvrir', ar: 'اكتشفي' })}
          </a>
        </div>
      </div>
    </section>
  );
}
