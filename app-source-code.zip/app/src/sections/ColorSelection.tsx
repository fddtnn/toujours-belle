import { useEffect, useRef, useState } from 'react';
import { useLanguage } from '../context/LanguageContext';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface HairColor {
  nameFr: string;
  nameAr: string;
  hex: string;
}

const hairColors: HairColor[] = [
  { nameFr: 'Noir', nameAr: 'أسود', hex: '#1a1a1a' },
  { nameFr: 'Ch\u00e2tain Fonc\u00e9', nameAr: 'بني غامق', hex: '#3d2b1f' },
  { nameFr: 'Ch\u00e2tain', nameAr: 'بني', hex: '#6b4423' },
  { nameFr: 'Ch\u00e2tain Clair', nameAr: 'بني فاتح', hex: '#a67c52' },
  { nameFr: 'Blond Fonc\u00e9', nameAr: 'أشقر غامق', hex: '#b8956a' },
  { nameFr: 'Blond Miel', nameAr: 'أشقر عسلي', hex: '#d4a76a' },
  { nameFr: 'Blond Clair', nameAr: 'أشقر فاتح', hex: '#e8c97a' },
  { nameFr: 'Blond Platine', nameAr: 'أشقر بلاتيني', hex: '#f5e6c8' },
  { nameFr: 'Auburn', nameAr: 'أوبورن', hex: '#722f37' },
  { nameFr: 'Rouge Bordeaux', nameAr: 'عنابي', hex: '#6b1a1a' },
  { nameFr: 'Cuivre', nameAr: 'نحاسي', hex: '#b87333' },
  { nameFr: 'Rouge', nameAr: 'أحمر', hex: '#c41e3a' },
  { nameFr: 'Gris', nameAr: 'رمادي', hex: '#8a8a8a' },
  { nameFr: 'Gris Argent', nameAr: 'فضي', hex: '#c0c0c0' },
  { nameFr: 'Rose Pastel', nameAr: 'وردي باستيل', hex: '#f5c6c6' },
  { nameFr: 'Violet', nameAr: 'بنفسجي', hex: '#6b3fa0' },
];

export default function ColorSelection() {
  const { t, lang, isRTL } = useLanguage();
  const sectionRef = useRef<HTMLElement>(null);
  const textRef = useRef<HTMLDivElement>(null);
  const swatchesRef = useRef<HTMLDivElement>(null);
  const [selectedColor, setSelectedColor] = useState<HairColor>(hairColors[0]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      if (textRef.current) {
        gsap.fromTo(
          textRef.current,
          { opacity: 0, x: isRTL ? 40 : -40 },
          {
            opacity: 1,
            x: 0,
            duration: 0.9,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 75%',
              toggleActions: 'play none none none',
            },
          }
        );
      }

      if (swatchesRef.current) {
        const swatches = swatchesRef.current.querySelectorAll('.color-swatch');
        gsap.fromTo(
          swatches,
          { opacity: 0, x: isRTL ? -40 : 40 },
          {
            opacity: 1,
            x: 0,
            duration: 0.9,
            ease: 'power3.out',
            stagger: 0.08,
            delay: 0.2,
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 75%',
              toggleActions: 'play none none none',
            },
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, [isRTL]);

  return (
    <section
      ref={sectionRef}
      id="colors"
      className="relative w-full"
      style={{
        zIndex: 1,
        backgroundColor: '#ffffff',
        padding: '120px 0',
      }}
    >
      <div className="max-w-[1200px] mx-auto px-6 lg:px-10">
        <div
          className="flex flex-col lg:flex-row gap-12 lg:gap-16 items-start"
          style={{ flexDirection: isRTL ? 'row-reverse' : undefined }}
        >
          {/* Text */}
          <div ref={textRef} className="w-full lg:w-[45%]">
            <p
              style={{
                fontFamily: "'Inter', sans-serif",
                fontWeight: 500,
                fontSize: '11px',
                letterSpacing: '0.15em',
                textTransform: 'uppercase',
                color: '#8a8a8a',
                marginBottom: '16px',
              }}
            >
              {t({ fr: 'PALETTE DE COULEURS', ar: 'لوحة الألوان' })}
            </p>
            <h2
              style={{
                fontFamily: "'Playfair Display', serif",
                fontWeight: 400,
                fontSize: 'clamp(2rem, 4vw, 3.5rem)',
                lineHeight: 1.15,
                color: '#1a1a1a',
                marginBottom: '20px',
              }}
            >
              {t({ fr: 'Plus de 16 Teintes', ar: 'أكثر من 16 لونًا' })}
            </h2>
            <p
              style={{
                fontFamily: "'Inter', sans-serif",
                fontWeight: 400,
                fontSize: '16px',
                lineHeight: 1.6,
                color: '#8a8a8a',
                marginBottom: '32px',
              }}
            >
              {t({
                fr: "Chaque type de cheveux est disponible dans une large gamme de couleurs naturelles et tendance. Choisissez la teinte qui sublime votre beaut\u00e9 unique.",
                ar: 'كل نوع من الشعر متوفر بمجموعة واسعة من الألوان الطبيعية والعصرية. اختاري اللون الذي يبرز جمالكِ الفريد.',
              })}
            </p>

            {/* Selected color preview */}
            <div
              className="w-full rounded-xl overflow-hidden hidden lg:block"
              style={{
                height: '240px',
                background: `linear-gradient(135deg, ${selectedColor.hex} 0%, ${selectedColor.hex}dd 100%)`,
                boxShadow: '0 8px 32px rgba(0,0,0,0.1)',
                transition: 'background 0.5s ease',
              }}
            >
              <div
                className="w-full h-full flex items-end p-6"
                style={{
                  background: 'linear-gradient(to top, rgba(0,0,0,0.3) 0%, transparent 60%)',
                }}
              >
                <p
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontWeight: 400,
                    fontSize: '1.5rem',
                    color: '#ffffff',
                    textShadow: '0 2px 8px rgba(0,0,0,0.3)',
                  }}
                >
                  {lang === 'fr' ? selectedColor.nameFr : selectedColor.nameAr}
                </p>
              </div>
            </div>
          </div>

          {/* Color Swatches */}
          <div ref={swatchesRef} className="w-full lg:w-[55%]">
            <div className="grid grid-cols-4 sm:grid-cols-8 gap-4 lg:gap-5">
              {hairColors.map((color) => (
                <button
                  key={color.hex}
                  className="color-swatch group flex flex-col items-center gap-2"
                  onClick={() => setSelectedColor(color)}
                  aria-label={lang === 'fr' ? color.nameFr : color.nameAr}
                >
                  <div
                    className="rounded-full transition-all duration-300"
                    style={{
                      width: '48px',
                      height: '48px',
                      backgroundColor: color.hex,
                      boxShadow:
                        selectedColor.hex === color.hex
                          ? '0 0 0 3px #1a1a1a'
                          : '0 0 0 0px transparent',
                      transform: selectedColor.hex === color.hex ? 'scale(1.15)' : 'scale(1)',
                    }}
                    onMouseEnter={(e) => {
                      if (selectedColor.hex !== color.hex) {
                        e.currentTarget.style.transform = 'scale(1.2)';
                        e.currentTarget.style.boxShadow = '0 0 0 3px #d4a5a5';
                      }
                    }}
                    onMouseLeave={(e) => {
                      if (selectedColor.hex !== color.hex) {
                        e.currentTarget.style.transform = 'scale(1)';
                        e.currentTarget.style.boxShadow = '0 0 0 0px transparent';
                      }
                    }}
                  />
                  <span
                    className="text-center"
                    style={{
                      fontFamily: "'Inter', sans-serif",
                      fontSize: '10px',
                      color: '#8a8a8a',
                      maxWidth: '60px',
                      lineHeight: 1.2,
                    }}
                  >
                    {lang === 'fr' ? color.nameFr : color.nameAr}
                  </span>
                </button>
              ))}
            </div>

            {/* Mobile color preview */}
            <div
              className="w-full rounded-xl overflow-hidden mt-8 lg:hidden"
              style={{
                height: '200px',
                background: `linear-gradient(135deg, ${selectedColor.hex} 0%, ${selectedColor.hex}dd 100%)`,
                boxShadow: '0 8px 32px rgba(0,0,0,0.1)',
                transition: 'background 0.5s ease',
              }}
            >
              <div
                className="w-full h-full flex items-end p-6"
                style={{
                  background: 'linear-gradient(to top, rgba(0,0,0,0.3) 0%, transparent 60%)',
                }}
              >
                <p
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontWeight: 400,
                    fontSize: '1.25rem',
                    color: '#ffffff',
                    textShadow: '0 2px 8px rgba(0,0,0,0.3)',
                  }}
                >
                  {lang === 'fr' ? selectedColor.nameFr : selectedColor.nameAr}
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
